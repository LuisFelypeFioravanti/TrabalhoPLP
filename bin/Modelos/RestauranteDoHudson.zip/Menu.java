package Modelos;

public interface Menu {
	
	public int getQtdItens();
}
