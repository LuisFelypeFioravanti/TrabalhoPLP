package Modelos;

public enum TipoPrato {
	P,B,S,PD;
}
