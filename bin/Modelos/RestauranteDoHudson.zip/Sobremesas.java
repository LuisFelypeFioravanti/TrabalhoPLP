package Modelos;

public class Sobremesas implements Menu {
	
	@Override
	public int getQtdItens() {
		
		return 0;
	}

}
