package Modelos;

public class PratosPrincipais implements Menu{
	
		@Override
		public int getQtdItens() {
			
			return 0;
			
	    }
}
