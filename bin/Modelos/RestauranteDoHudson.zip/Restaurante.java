package Modelos;

public class Restaurante {
	public String nome;
	public String endereco;
	public Integer telefone;
	public boolean entrega;
	public int qtdFuncionarios;
	private int CNPJ;
	
	public Restaurante(String nome, int CNPJ, String endereco) {
		super();
		// TODO Auto-generated constructor stub
	}

}
